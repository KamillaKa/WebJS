export default {
  base: './',
};
