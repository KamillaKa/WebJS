const apiUrl = 'https://student-restaurants.azurewebsites.net/api/v1';
const uploadUrl = 'https://student-restaurants.azurewebsites.net/uploads/';

export {apiUrl, uploadUrl};
