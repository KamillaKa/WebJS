# JavaScript Starter

For Basics of Web Development course in Metropolia.
