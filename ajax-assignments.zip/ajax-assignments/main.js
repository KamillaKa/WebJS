function greeting(name) {
  console.log(name);
}

greeting();
